<?php

$my_date = $_SESSION['start_date'];
$type = 'FLIGHT';
$origin_base = $_SESSION['origin_base'];

if($_SESSION['origin_base']){
  $location = $_SESSION['origin_base'];
}else{
  $location = 'ALL BASE';
}


$approval = $this->mymodel->selectWithQuery("SELECT * FROM approval WHERE DATE(date) = '$my_date' AND type = '$type' AND base = '$origin_base'
LIMIT 1");

$approval = $approval[0];

$created_at = $approval['created_at'];

if($_SESSION['origin_base']){
$left = '
  <p>'.$location.', '.DATE('d M Y', strtotime($approval['prepared_time'])).'</p>
  <p>Prepared By;
    ';
}else{
  $left = '
  <p style="color:#fff">'.$location.'</p>
  <p>Prepared By;
    ';
}

    $right = '<p>I hereby declare that the above report is in accordance
    with PT. BIFA requirements and regulations</p><p>Approved By;</p>
';



$dat = $this->mymodel->selectDataOne('user', array('id'=>$approval['prepared_by']));
$role = $this->mymodel->selectDataOne('role', array('id'=>$dat['role_id']));
$file_prepared_by = $this->mymodel->selectDataOne('file', array('table'=>'file_signature', 'table_id' => $dat['id']));
$base_dat = $this->mymodel->selectDataOne('base_airport_document', array('id'=>$dat['base']));
$prepared_by = '<u>'.$dat['name'].'</u><br>'.$role['role'].' '.$base_dat['base'];


$dat = $this->mymodel->selectDataOne('user', array('id'=>$approval['approved_by']));
$role = $this->mymodel->selectDataOne('role', array('id'=>$dat['role_id']));
$file_approved_by = $this->mymodel->selectDataOne('file', array('table'=>'file_signature', 'table_id' => $dat['id']));
$base_dat = $this->mymodel->selectDataOne('base_airport_document', array('id'=>$dat['base']));
$approved_by= '<u>'.$dat['name'].'</u><br>'.$role['role'].' '.$base_dat['base'];

$dat = $this->mymodel->selectDataOne('user', array('id'=>$approval['approved_by_2']));
$role = $this->mymodel->selectDataOne('role', array('id'=>$dat['role_id']));
$file_approved_by_2 = $this->mymodel->selectDataOne('file', array('table'=>'file_signature', 'table_id' => $dat['id']));
$base_dat = $this->mymodel->selectDataOne('base_airport_document', array('id'=>$dat['base']));
$approved_by_2=  '<u>'.$dat['name'].'</u><br>'.$role['role'].' '.$base_dat['base'];

if($approval['approval_status']=='APPROVED'){
  $right = $right.'<br>
  <img src="'.base_url().'webfile/'.$file_approved_by['name'].'" style="height:40px;">
  <br>'.$approved_by;
}else{
  $right = $right.'<br><br><br><br><br>'.$approved_by;
}



if($file_prepared_by['name']){
  $left = $left.'<br>
  <img src="'.base_url().'webfile/'.$file_prepared_by['name'].'" style="height:40px;">
  <br>'.$prepared_by;
}else{
  $left = $left.'<br><br><br><br><br>'.$prepared_by;
}





$start_date = $_SESSION['start_date'];
$end_date = $_SESSION['end_date'];
$origin_base = $_SESSION['origin_base'];

if(empty($start_date)){
  $_SESSION['start_date'] = DATE('Y-m-d');
  $_SESSION['end_date'] = DATE('Y-m-d');
  $start_date = $_SESSION['start_date'];
  $end_date = $_SESSION['end_date'];
}

if(empty($end_date)){
  $_SESSION['start_date'] = DATE('Y-m-d');
  $_SESSION['end_date'] = DATE('Y-m-d');
  $start_date = $_SESSION['start_date'];
  $end_date = $_SESSION['end_date'];
}

if($origin_base){
  $origin_base = "  AND a.origin_base = '$origin_base' ";
}else{
  $origin_base = " ";
}


$batch = $_SESSION['batch'];
if($batch){
	$batch = "  AND a.batch = '$batch' ";
}else{
	$batch = " ";
}
  

// print_r($data);
?>
<style>
  body{
    /* margin-top:-20px; */
    margin:-30px;
    margin-top:85px;
  }
  tr,th,td{
    border:1px #000 solid;
    padding:5px;
    font-size:9px;
    text-align:center;
  }
  th{
    text-align:center;
  }
  .text-left{
    text-align:left;
  }
  .text-center{
    text-align:center;
  }
  table{
    width: 100%;
  border-collapse: collapse;
  }
  
  .no-border{
    border-style:none;
    padding-left:0px;
    text-align:left:
  }
  p{
    margin:3px 0px;
  }
  .bg-success{
    background:#bfbfbf;
  }
</style>
<title>DAILY FLIGHT SCHEDULE</title>
<body>
<table class="table table-bordered table-striped" id="" style="width:100%">

<tr>
    <th colspan="14" style="font-size:12px;"><?=$date?>
    </th>
  </tr>
<tr class="bg-success">

  <th>NO</th><th>AIRCRAFT<br>REG</th><th>PIC</th><th>2ND</th><th>COURSE</th>
  <th>MISSION</th>
  <th>DEP</th><th>ARR</th>
  <th>ROUTE</th><th>BATCH</th><th>ETD<br>UTC</th><th>ETA<br>UTC</th><th>EET</th><th>REMARK</th>

</tr>

<?php 

$data_date =  $this->template->date_range( $start_date, $end_date);

$duty_instructor = '';
$total = array();
$array_aircraft = array();
$array_duty_instructor = array();
$array_base = array();

$nomor = 0;
foreach($data_date as $v=>$k){
  $start_date = $k;
  $end_date = $k;
?>



<?php 


$data = $this->mymodel->selectWithQuery("SELECT a.id,h.nick_name as duty_instructor, a.date_of_flight,a.origin_base,b.serial_number as aircraft_reg,f.nick_name as pic,g.nick_name as 2nd,d.course_code as course,c.batch,e.id as id_mission, CONCAT(e.name) as mission,e.name as mission_name,a.description,a.rute,a.etd_utc,a.eta_utc,a.eet,a.dep,a.arr,a.remark,a.status
FROM daily_flight_schedule a
LEFT JOIN
aircraft_document b
ON a.aircraft_reg = b.id
LEFT JOIN
batch c 
ON a.batch = c.id
LEFT JOIN
course d
ON a.course = d.id
LEFT JOIN
tpm_syllabus_all_course e
ON a.mission = e.id
LEFT JOIN
student_application_form f
ON a.pic = f.id
LEFT JOIN student_application_form g
ON a.2nd = g.id
LEFT JOIN student_application_form h
ON a.duty_instructor = h.id
WHERE DATE(a.date_of_flight) >= '$start_date' AND DATE(a.date_of_flight) <= '$end_date' AND a.visibility = '1'  AND etd_utc >= '22:00' AND etd_utc <= '24:00'
AND a.type = ''
"
.$batch
.$origin_base.

"
ORDER BY
a.date_of_flight ASC, a.etd_utc ASC");

foreach($data as $key=>$val){
  $nomor++;
  
  if(!in_array($val['aircraft_reg'],$array_aircraft)){
    array_push($array_aircraft,$val['aircraft_reg']);
  }

  if(!in_array($val['origin_base'],$array_base)){
    array_push($array_base,$val['origin_base']);
  }
  
  if(!in_array($val['duty_instructor'],$array_duty_instructor)){
    array_push($array_duty_instructor,$val['duty_instructor']);
  }

  if($val['duty_instructor']){
    $duty_instructor = $val['duty_instructor'];
  }
  if (strpos($val['eet'], ':') !== false) {
    array_push($total,$val['eet']);
  }
 
    $val['pic'] = $val['pic'];

  ?>
  
  <tr>
    <td style="width:3%"><?=$nomor?></td>
   
    <td style="width:5%"><?=$val['aircraft_reg']?></td>
    <td class="text-left" style="width:10%"><?=$val['pic']?></td>
    <td class="text-left" style="width:10%"><?=$val['2nd']?></td>
    <td style="width:5%"><?=$val['course']?></td>
    
    <td class="text-left" style="width:10%"><?=$val['mission']?></td>

    <td style="width:5%"><?=$val['dep']?></td>
    <td style="width:5%"><?=$val['arr']?></td>
    
    <td class="text-left" style="width:15%"><?=$val['rute']?></td>
    <td style="width:5%"><?=$val['batch']?></td>
    <td style="width:5%"><?=$val['etd_utc']?></td>
    <td style="width:5%"><?=$val['eta_utc']?></td>
    <td style="width:5%"><?=$val['eet']?></td>
    <td class="text-left" style="width:12%"><?=$val['remark']?></td>
  </tr>
<?php } ?>


<?php 


$data = $this->mymodel->selectWithQuery("SELECT a.id,h.nick_name as duty_instructor, a.date_of_flight,a.origin_base,b.serial_number as aircraft_reg,f.nick_name as pic,g.nick_name as 2nd,d.course_code as course,c.batch,e.id as id_mission, CONCAT(e.name) as mission,e.name as mission_name,a.description,a.rute,a.etd_utc,a.eta_utc,a.eet,a.dep,a.arr,a.remark,a.status
FROM daily_flight_schedule a
LEFT JOIN
aircraft_document b
ON a.aircraft_reg = b.id
LEFT JOIN
batch c 
ON a.batch = c.id
LEFT JOIN
course d
ON a.course = d.id
LEFT JOIN
tpm_syllabus_all_course e
ON a.mission = e.id
LEFT JOIN
student_application_form f
ON a.pic = f.id
LEFT JOIN student_application_form g
ON a.2nd = g.id
LEFT JOIN student_application_form h
ON a.duty_instructor = h.id
WHERE DATE(a.date_of_flight) >= '$start_date' AND DATE(a.date_of_flight) <= '$end_date' AND a.visibility = '1'   AND etd_utc >= '00:00' AND etd_utc <= '21:59'
AND a.type = ''
"
.$batch
.$origin_base.

"
ORDER BY
a.date_of_flight ASC, a.etd_utc ASC");

foreach($data as $key=>$val){
  $nomor++;
  
  if(!in_array($val['aircraft_reg'],$array_aircraft)){
    array_push($array_aircraft,$val['aircraft_reg']);
  }

  if(!in_array($val['origin_base'],$array_base)){
    array_push($array_base,$val['origin_base']);
  }
  
  if(!in_array($val['duty_instructor'],$array_duty_instructor)){
    array_push($array_duty_instructor,$val['duty_instructor']);
  }

  if($val['duty_instructor']){
    $duty_instructor = $val['duty_instructor'];
  }
  if (strpos($val['eet'], ':') !== false) {
    array_push($total,$val['eet']);
  }
 
    $val['pic'] = $val['pic'];

  ?>
  
  <tr>
    <td style="width:3%"><?=$nomor?></td>
   
    <td style="width:5%"><?=$val['aircraft_reg']?></td>
    <td class="text-left" style="width:10%"><?=$val['pic']?></td>
    <td class="text-left" style="width:10%"><?=$val['2nd']?></td>
    <td style="width:5%"><?=$val['course']?></td>
    
    <td class="text-left" style="width:10%"><?=$val['mission']?></td>

    <td style="width:5%"><?=$val['dep']?></td>
    <td style="width:5%"><?=$val['arr']?></td>
    
    <td class="text-left" style="width:15%"><?=$val['rute']?></td>
    <td style="width:5%"><?=$val['batch']?></td>
    <td style="width:5%"><?=$val['etd_utc']?></td>
    <td style="width:5%"><?=$val['eta_utc']?></td>
    <td style="width:5%"><?=$val['eet']?></td>
    <td class="text-left" style="width:12%"><?=$val['remark']?></td>
  </tr>
<?php } ?>
<!-- <tr>
  <td colspan="14" style="padding:0.1px;background:#000;" ></td>
</tr> -->
<?php

}

  $total_plan = $this->template->sum_time($total);
  $total_aircraft = count($array_aircraft);
  $total_flight = $nomor;
?>



<?php
    $text = "";
    foreach($array_duty_instructor as $key=>$val){
      if($val){
        $text .= ''.$val.', ';
      }
    }
    $text = substr($text,0,-2);


    ?>


</table>
<br><br>
<table>
  <tr>
  <th class="text-left no-border">
    <p>DUTY INSTRUCTOR</p>
  </th>
  <th class="text-left no-border">
    <p>:</p>
  </th>
  <th class="text-left no-border" colspan="3">
    <p><?=$text?></p>
  </th>
  </tr>
  <tr>
    <th class="text-left no-border" style="width:15%">
    
    <p>TOTAL FLIGHT SCHEDULE</p> 

    <p>TOTAL AIRCRAFT IN USE </p>
  
    <p>TOTAL PLAN</p> 
    
    </th>
    <th class="no-border" style="width:1%">
    <p>:</p>
    <p>:</p>
    <p>:</p>
    </th>
    <th class="text-left no-border" style="width:15%">
    <p><?=$total_flight?></p>
    <p><?=$total_aircraft?></p>
    <p><?=$total_plan?></p>
    </th>
    <td class="no-border" style="width:15%;">

    <?php


    if($approval['base']){

    }else{
      foreach($array_base as $key=>$val){
        $base = $base . $val.', ';
      }

      $base = substr($base,0,-2);
      $left = $left.'<br><br><br>'.$base;
      $right = $right.'<br><br><br>'.$base;
      }
?>

<?=$left?>
</td>
    <td class="no-border" style="width:30%;vertical-align:top">
   <?=$right?>
</td>
  </tr>
</table>

</body>