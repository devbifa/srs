<?php
                $id = $this->uri->segment(4);
                $student = $this->mymodel->selectDataOne('student_application_form',array('id'=>$id));
                $batch = $this->mymodel->selectDataOne('batch',array('id'=>$student['batch']));
                $curriculum = $this->mymodel->selectDataOne('curriculum',array('id'=>$batch['curriculum']));
                $id_curriculum = $curriculum['id'];
                $course = $this->mymodel->selectWithQuery("SELECT * FROM course WHERE curriculum = '$id_curriculum' AND (configuration LIKE '%GROUND%' OR configuration LIKE '%FTD%' OR configuration LIKE '%FLIGHT%') ORDER BY position ASC");
     
             ?>



 <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">


    <!-- Main content -->

    <section class="content">

      <div class="row">

        <div class="col-xs-12">

          <div class="box">

            <!-- /.box-header -->

            <div class="box-header-material box-header-material-text">
                <div class="row">
                <div class="col-xs-10">
              STUDENT HOURS DETAIL 
              <?php $this->load->view('record/student_hours/menu.php')?>
                </div>
                <div class="col-xs-2">
                    <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    </div>
                </div>
                </div>
            </div>

            

            <div class="box-body">

            

            <table style="width:100%;">
              <tr>
              <th colspan="3" style="font-size:15px;width:20%;padding:5px 0px;" class="text-left">STUDENT NAME</th>
                <th>:</th>
                <th class="text-left"><?=$student['full_name']?></th>
                <th colspan="4"></th>
              </tr>
              <tr>
                <th colspan="3" style="font-size:15px;padding:5px 0px;" class="text-left">NICK NAME</th>
                <th>:</th>
                <th class="text-left"><?=$student['nick_name']?></th>
                <th colspan="4"></th>
              </tr>
              <tr>
                <th colspan="3" style="font-size:15px;padding:5px 0px;" class="text-left">BATCH</th>
                <th>:</th>
                <th class="text-left"><?=$batch['batch']?></th>
                <th colspan="4"></th>
              </tr>
              <tr>
                <th colspan="3" style="font-size:15px;padding:5px 0px;" class="text-left">CURRICULUM</th>
                <th>:</th>
                <th class="text-left"><?=$curriculum['curriculum']?></th>
                <th colspan="4"></th>
              </tr>

            </table>
            <br>
            <?php 
            $training_requirement = json_decode($student['training_requirement'],true);
            
            foreach($course as $key=>$val){
            $no_ground = 0;
            $no_flight = 0;
            $no_ftd = 0;
            $id_course = $val['id'];
            $ground_mission = $this->mymodel->selectWithQuery("SELECT * FROM tpm_syllabus_all_course WHERE course = '$id_course' AND type_of_training = 'GROUND' ORDER BY mission_number ASC");
            $ftd_mission = $this->mymodel->selectWithQuery("SELECT * FROM tpm_syllabus_all_course WHERE course = '$id_course' AND type_of_training = 'SIM' ORDER BY mission_number ASC");
            $flight_mission = $this->mymodel->selectWithQuery("SELECT * FROM tpm_syllabus_all_course WHERE course = '$id_course' AND type_of_training = 'FLIGHT' ORDER BY mission_number ASC");
            ?>

<?php 

if(empty($training_requirement['GROUND']['item'][$val['id']]) AND empty($training_requirement['FTD']['item'][$val['id']]) AND empty($training_requirement['FLIGHT']['item'][$val['id']])){
  $style_parent = "style='display:none;'";
}else{
  $style_parent = "";
}
 // print_r();
?>

          <div <?=$style_parent?> >
            <table style="width:100%;" class="table table-bordered">
              <tr class="bg-orange">
                <th colspan="6" style="font-size:15px;" class="text-left"> <label><?=$val['course_code']?> - <?=$val['course_name']?></label>
                </th>
              </tr>
              <?php 

                   if($training_requirement['GROUND']['item'][$val['id']]){
                    $style_parent = "";
                   }else{
                    $style_parent = "style='display:none;'";
                   }
                    // print_r();
              ?>
              <tr <?=$style_parent?> >
                <th class="text-left" colspan="6">GROUND</th>
              </tr>
              <tr class="bg-success" <?=$style_parent?>>
                <th style="min-width:30px;">
                NO
                </th>
                <th style="min-width:100px;">
                  DATE
                </th>
                <th style="min-width:30px;">
                CODE
                </th>
                <th>
                MISSION
                </th>
                <th style="min-width:50px;">
                TPM
                </th>
                <th style="min-width:50px;">
                  FT
                </th>
              </tr>
              <?php 
              $target_ground = array();
              $total_ground = array();
              foreach($ground_mission as $key2=>$val2){ 
                 
                 $id_student = $student['id']; 
                 $id_mission = $val2['id'];
                 $total = array();
                 $qry = '{"attend":"'.$id_student.'"}';
                 $data = $this->mymodel->selectWithQuery("SELECT * FROM daily_ground_schedule WHERE subject = '$id_mission' AND student_attend LIKE '%$qry%' ");
                 $date_report = '';
                 foreach($data as $key3=>$val3){
                   if (strpos($val3['duration'], ':') !== false) {
                     array_push($total,$val3['duration']);
                    $date_report .= '<a href="'.base_url().'master/daily_attendance_report/edit/'.$val3['id'].'">'.DATE('d M Y', strtotime($val3['date'])).'</a><br>';
                   }
                 }

                $total = $this->template->sum_time($total);
 
                 $duration = array();
                   if (strpos($val2['duration'], ':') !== false) {
                     array_push($duration,$val2['duration']);
                   }
                 
                   $duration = $this->template->sum_time($duration);
                  
                   
                  $total1 = (explode(":",$total));

                  $duration1 = (explode(":",$duration));

                  if($total1[0] == $duration1[0] && $total1[1] >= $duration1[1] ){
                    $status = "COMPLETE";
                    $style_status = "style='color:green;'";
                  }else if($total1[0] > $duration1[0]){
                    $status = "COMPLETE";
                     $style_status = "style='color:green;'";
                  }else{
                     $status = "NOT COMPLETE";
                     $style_status = "style='color:red;'";
                  }
                   $no_ground++;

                ?>
                <tr <?=$style_parent?> >
                <td><?=$no_ground?></td>
                <td><?=$date_report?></td>
                <td><?=$val2['subject_mission']?></td>
                <td class="text-left"><?=$val2['name']?></td>
                  <td><?=$duration?></td>
                  <td <?=$style_status?> ><?=$total?></td>
                
              </tr>
              <?php 
                array_push($target_ground,$duration);
                array_push($total_ground,$total);
            } 
            
            // print_r($total_ground);
            $target_ground = $this->template->sum_time($target_ground);
            $total_ground = $this->template->sum_time($total_ground);
            ?>

              <tr <?=$style_parent?> >
                <th class="text-right" colspan="4">TOTAL</th>
                <th><?=$target_ground?></th>
                <th><?=$total_ground?></th>
              </tr>

              <?php 

if($training_requirement['FTD']['item'][$val['id']]){
 $style_parent = "";
}else{
 $style_parent = "style='display:none;'";
}
 // print_r();
?>
<tr <?=$style_parent?> >

                <th class="text-left" colspan="6">FTD</th>
</tr>
                <tr class="bg-success" <?=$style_parent?>>
                <th>
                NO
                </th>
                <th>
                  DATE
                </th>
                <th>
                CODE
                </th>
                <th>
                MISSION
                </th>
                <th>
                TPM
                </th>
                <th>
                  FT
                </th>
              </tr>
              <?php 
              $total_ftd = array();
              $target_ftd = array();
              foreach($ftd_mission as $key2=>$val2){
                $id_student = $student['id']; 
                $id_mission = $val2['id'];
                $total = array();
                $data = $this->mymodel->selectWithQuery("SELECT * FROM daily_ftd_schedule WHERE mission = '$id_mission' AND (2nd = '$id_student' OR pic = '$id_student') ");
                $date_report = '';
                foreach($data as $key3=>$val3){
                  if (strpos($val3['block_time_total'], ':') !== false) {
                    array_push($total,$val3['block_time_total']);
                    $date_report .= '<a href="'.base_url().'master/daily_ftd_report/edit/'.$val3['id'].'">'.DATE('d M Y', strtotime($val3['date'])).'</a><br>';
                  }
                }
                $total = $this->template->sum_time($total);

                
                $duration = array();
                  if (strpos($val2['duration'], ':') !== false) {
                    array_push($duration,$val2['duration']);
                  }
                
                  $duration = $this->template->sum_time($duration);
                
                  $total1 = (explode(":",$total));

                  $duration1 = (explode(":",$duration));

                  if($total1[0] == $duration1[0] && $total1[1] >= $duration1[1] ){
                    $status = "COMPLETE";
                    $style_status = "style='color:green;'";
                  }else if($total1[0] > $duration1[0]){
                    $status = "COMPLETE";
                     $style_status = "style='color:green;'";
                  }else{
                     $status = "NOT COMPLETE";
                     $style_status = "style='color:red;'";
                  }
                   $no_ftd++;
                ?>
                <tr <?=$style_parent?>>
                <td><?=$no_ftd?></td>
                <td><?=$date_report?></td>
                <td><?=$val2['subject_mission']?></td>
                <td class="text-left"><?=$val2['name']?></td>
                <td><?=$val2['duration']?></td>
                <td <?=$style_status?> ><?=$total?></td>
                
              </tr>
              <?php 
                array_push($target_ftd,$duration);
                array_push($total_ftd,$total);
            } 
            
            // print_r($total_ground);
            $target_ftd = $this->template->sum_time($target_ftd);
            $total_ftd = $this->template->sum_time($total_ftd);
            ?>

              

              <tr <?=$style_parent?> >
                <th class="text-right" colspan="4">TOTAL</th>
                <th><?=$target_ftd?></th>
                <th><?=$total_ftd?></th>
              </tr>

              <?php 

if($training_requirement['FLIGHT']['item'][$val['id']]){
 $style_parent = "";
}else{
 $style_parent = "style='display:none;'";
}
 // print_r();
?>
<tr <?=$style_parent?> >
<th class="text-left" colspan="6">FLIGHT</th>
</tr>
                <tr class="bg-success" <?=$style_parent?>>
                <th>
                NO
                </th>
                <th>
                  DATE
                </th>
                <th>
                CODE
                </th>
                <th>
                MISSION
                </th>
                <th>
                TPM
                </th>
                <th>
                  FT
                </th>
              </tr>
              <?php 
                $total_flight = array();
                $target_flight = array();
                foreach($flight_mission as $key2=>$val2){ 
                $id_student = $student['id']; 
                $id_mission = $val2['id'];
                $total = array();
                $data = $this->mymodel->selectWithQuery("SELECT * FROM daily_flight_schedule WHERE mission = '$id_mission' AND (2nd = '$id_student' OR pic = '$id_student')");
                $date_report = '';
                foreach($data as $key3=>$val3){
                  if (strpos($val3['block_time_total'], ':') !== false) {
                    array_push($total,$val3['block_time_total']);
                    $date_report .= '<a href="'.base_url().'master/daily_movement_report/edit/'.$val3['id'].'">'.DATE('d M Y', strtotime($val3['date_of_flight'])).'</a><br>';
                  }
                }
                $total = $this->template->sum_time($total);

                $duration = array();
                  if (strpos($val2['duration_dual'], ':') !== false) {
                    array_push($duration,$val2['duration_dual']);
                  }
                  if (strpos($val2['duration_solo'], ':') !== false) {
                    array_push($duration,$val2['duration_solo']);
                  }
                  if (strpos($val2['duration_pic'], ':') !== false) {
                    array_push($duration,$val2['duration_pic']);
                  }
                  if (strpos($val2['duration_pic_solo'], ':') !== false) {
                    array_push($duration,$val2['duration_pic_solo']);
                  }
                  $duration = $this->template->sum_time($duration);

                  // echo $total.'-'.$duration.'<br>';
                  
                  $total1 = (explode(":",$total));

                  $duration1 = (explode(":",$duration));

                  if($total1[0] == $duration1[0] && $total1[1] >= $duration1[1] ){
                    $status = "COMPLETE";
                    $style_status = "style='color:green;'";
                  }else if($total1[0] > $duration1[0]){
                    $status = "COMPLETE";
                     $style_status = "style='color:green;'";
                  }else{
                     $status = "NOT COMPLETE";
                     $style_status = "style='color:red;'";
                  }

                   $no_flight++;

                ?>
                <tr <?=$style_parent?>>
                <td><?=$no_flight?></td>
                <td><?=$date_report?></td>
                <td><?=$val2['subject_mission']?></td>
                <td class="text-left"><?=$val2['name']?></td>
                <td><?=$duration?></td>
                <td <?=$style_status?> ><?=$total?></td>
                
              </tr>

              <?php 
                array_push($target_flight,$duration);
                array_push($total_flight,$total);
            } 
            
            // print_r($total_ground);
            $target_flight = $this->template->sum_time($target_flight);
            $total_flight = $this->template->sum_time($total_flight);
            ?>

              

              <tr <?=$style_parent?> >
                <th class="text-right" colspan="4">TOTAL</th>
                <th><?=$target_flight?></th>
                <th><?=$total_flight?></th>
              </tr>
              

            </table>
                  </div>
<br>
            <?php } ?>
            
            
                    



            </div>

            <!-- /.box-body -->

          </div>

          <!-- /.box -->

        </div>

        <!-- /.col -->

      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->


  <div class="modal modal-danger fade" id="modal-delete">

  <div class="modal-dialog">
            <div class="modal-content">

              <form id="upload-delete" action="<?= base_url('dashboard/flight_schedule/delete') ?>">

              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">DELETE DATA</h4>
              </div>

              <div class="modal-body">

                  <input type="hidden" name="id" id="delete-input">

                  <p>Are you sure to delete this data?</p>

              </div>

              <div class="modal-footer">

                 
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-outline btn-send" href="">Delete Now</button>

              </div>

              </form>

          </div>

      </div>

  </div> 



  <div class="modal fade" id="modal-impor">

    <div class="modal-dialog">

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

          <h4 class="modal-title">IMPORT DATA</h4>

        </div>

        <form action="<?= base_url('fitur/impor/daily_flight_schedule') ?>" method="POST"  enctype="multipart/form-data">



        <div class="modal-body">

            <div class="form-group">

              <label for="">File Excel</label>

              <input type="file" class="form-control" id="" name="file" placeholder="Input field">

            </div>

        </div>

        <div class="modal-footer">

          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>

          <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>

        </div>

        </form>



      </div>

    </div>

  </div>


