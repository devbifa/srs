<div class="row">

  <div class="col-md-12">
  <p style="text-align:center;">Selamat datang di sistem aplikasi NSO Project!</p>
  <br>

  <p class="help-block pull-right">Sudah Punya Akun? <a>Masuk Disini </a></p>
  <a  href="<?=$this->google_url?>"><button class="btn btn-block btn-blog">Login With Google</button></a>
  </div> 
  
  <div class="col-md-12">
  <p class="help-block pull-right"><a>Belum Punya Akun? Daftar Disini </a></p>
  <a  href="<?=$this->google_url?>"><button class="btn btn-block btn-blog">Register With Google</button></a>
  </div>
</div>
